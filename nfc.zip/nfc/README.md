# NFC Craft Pro 📱⚡

An advanced Android application leveraging the **Android NFC API** (`NfcAdapter`, `Ndef`, `NdefFormatable`, `NdefRecord`, `NdefMessage`, `ReaderCallback`) to write, format, inspect, and permanently lock NFC cards and tags with extensive configuration options.

---

## 🚀 Key Features

### 1. 13 Supported Record Types
- **Website / URL**: Custom URLs, links, social profiles with shortcut chips (`.com`, `.io`, `.org`, GitHub, LinkedIn).
- **Text**: Custom text and notes with **UTF-8** or **UTF-16** character encoding and ISO language code configuration.
- **Digital Business Card (vCard 3.0)**: Name, company, job title, phone, email, website, physical address, and note.
- **Wi-Fi Network Configuration**:
  - Connect to wireless networks automatically.
  - Supports **WPA2 Personal (PSK)**, **WPA3 Personal (SAE)**, **WEP**, and **Open** networks.
  - Hidden network flag support.
  - Dual encoding: Standard NFC Forum / Wi-Fi Alliance Simple Configuration (WSC) binary payload (`application/vnd.wfa.wsc`) or standard Wi-Fi URI format.
- **Bluetooth Pairing**: Out-Of-Band (OOB) pairing record (`application/vnd.bluetooth.ep.oob`) with device MAC address and friendly device name.
- **Android Application Record (AAR)**: Instructs Android devices to automatically launch or install an app from Google Play Store. Includes quick presets for YouTube, Spotify, Maps, WhatsApp, Telegram, etc.
- **Phone Call**: Quick telephone dialer trigger (`tel:`).
- **SMS Message**: Pre-filled SMS recipient and message body.
- **Email**: Pre-filled recipient, subject line, and body.
- **Geo-Location**: GPS coordinates (Latitude & Longitude) with custom query labels and quick city presets.
- **Custom MIME**: Arbitrary MIME media types (e.g., `application/json`, `text/markdown`, custom payloads) for automation in Home Assistant, Tasker, or Node-RED.
- **External Type**: NFC Forum standard external record (`urn:nfc:ext:domain:type`).
- **Raw Hex / Custom Payload**: Enter direct hexadecimal bytes with custom TNF (Type Name Format), type byte, ID byte, and payload.

---

### 2. Comprehensive Write & Card Security Options
- 🔒 **Permanent Read-Only Lock (`Ndef.makeReadOnly`)**:
  - Locks the hardware lock bits on supported NFC chips (e.g. NTAG213, NTAG215, NTAG216).
  - Includes confirmation warning dialog so cards are not locked accidentally.
- 🔄 **Auto-Format Blank Tags (`NdefFormatable.format`)**:
  - Automatically initializes and formats unformatted raw tags into NDEF.
  - Also supports formatting directly into read-only mode (`formatReadOnly`).
- 📦 **Append Android Application Record (AAR)**:
  - Inject an AAR record into *any* payload so Android devices prioritize launching your app when scanned.
- ⚡ **Force Overwrite**:
  - Safely replace existing NDEF contents.
- 📳 **Haptic & Sound Feedback**:
  - Instant dual-pulse vibration and tone chime when card contact is detected and write operation succeeds.

---

### 3. Multi-Record NDEF Composer
- Queue and bundle multiple records into a single tag payload (e.g. **vCard + Website link + AAR** or **Wi-Fi + Geo-Location**).
- Real-time estimated byte counter and tag compatibility indicators (**NTAG213: 144B**, **NTAG215: 504B**, **NTAG216: 888B**).

---

### 4. Tag Diagnostics & Inspector Mode
- Tap any NFC tag to instantly view:
  - **UID** in Hexadecimal and Decimal.
  - **Supported Technologies** (`NfcA`, `Ndef`, `NdefFormatable`, `MifareUltralight`, `IsoDep`, etc.).
  - **Memory Utilization** progress bar (`current bytes / max bytes`).
  - **Tag Type** (e.g. NFC Forum Type 2, NTAG215, etc.).
  - **Lock State**: `WRITABLE` vs `READ-ONLY`.
  - **Stored Records Inspection**: Decodes and displays TNF, Type, ID, Payload preview, and byte size for all records currently on the card.

---

### 5. Presets & Template Hub
- Pre-configured profiles: *Digital Business Card*, *Guest Wi-Fi Hotspot*, *Emergency ICE Medical Info*, *Smart Home Automation Trigger*, *YouTube Launcher*, and *Meeting Point Pin*.
- Save your own custom configurations into local presets with 1-tap loading.

---

## 🛠️ Compiling in Ubuntu

### Step 1: Install Prerequisites (OpenJDK 17 or 21 & Android SDK)
```bash
# Update package lists
sudo apt update

# Install OpenJDK 17
sudo apt install -y openjdk-17-jdk

# Verify Java version
java -version
```

### Step 2: Setup Android SDK Command-Line Tools
If you already have Android Studio or the Android SDK installed:
```bash
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools
```

If you need command-line tools only:
```bash
sudo apt install -y unzip wget
mkdir -p $HOME/Android/Sdk/cmdline-tools
cd $HOME/Android/Sdk/cmdline-tools
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip commandlinetools-linux-*.zip
mv cmdline-tools latest

# Accept licenses and install platform
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools
yes | sdkmanager --licenses
sdkmanager "platforms;android-35" "build-tools;35.0.0"
```

### Step 3: Build the APK
Navigate to the project root directory:
```bash
cd /path/to/nfc

# Ensure gradlew has execute permissions
chmod +x ./gradlew

# If gradle-wrapper.jar is not already downloaded, you can build with installed gradle:
# sudo apt install -y gradle
# gradle assembleDebug

# Or using the wrapper:
./gradlew assembleDebug
```

The compiled APK will be generated at:
```
app/build/outputs/apk/debug/app-debug.apk
```

### Step 4: Install APK to Device via ADB
Connect your Android phone with USB Debugging enabled:
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

---

## 🏷️ NFC Tag Compatibility Guide

| Chip Type | Usable Memory | Typical Use Cases | Locking Supported |
|---|---|---|---|
| **NTAG213** | 144 Bytes | Short URLs, Phone, SMS, Plain text, App launcher | Yes (`makeReadOnly`) |
| **NTAG215** | 504 Bytes | vCards, Wi-Fi credentials, Multi-record payloads, Amiibo | Yes (`makeReadOnly`) |
| **NTAG216** | 888 Bytes | Large vCards, JSON payloads, Multiple complex records | Yes (`makeReadOnly`) |
| **Mifare Ultralight** | 48-128 Bytes | Tickets, short text | Yes |
| **Mifare Classic 1K** | 716-752 Bytes (NDEF) | Proprietary NXP tags *(requires NXP NFC chip on phone)* | Dependent on sector keys |

> [!WARNING]
> When testing the **Make Card Read-Only (Permanent Lock)** option, make sure you use an inexpensive test tag! Hardware locking is irreversible.
