package com.example.nfcwriter.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.nfcwriter.model.NfcRecordConfig
import com.example.nfcwriter.model.NfcRecordType
import com.example.nfcwriter.model.WifiAuthType
import com.example.nfcwriter.ui.theme.CyanPrimary
import com.example.nfcwriter.ui.theme.DarkOutline
import com.example.nfcwriter.ui.theme.DarkSurfaceVariant
import com.example.nfcwriter.ui.theme.TextMuted
import com.example.nfcwriter.ui.theme.TextPrimary
import com.example.nfcwriter.ui.theme.TextSecondary
import com.example.nfcwriter.ui.viewmodel.NfcViewModel

@Composable
fun RecordFormContainer(
    viewModel: NfcViewModel,
    modifier: Modifier = Modifier
) {
    val selectedType by viewModel.selectedRecordType.collectAsState()

    Column(modifier = modifier.fillMaxWidth()) {
        when (selectedType) {
            NfcRecordType.URL -> UrlRecordForm(viewModel)
            NfcRecordType.TEXT -> TextRecordForm(viewModel)
            NfcRecordType.VCARD -> VCardRecordForm(viewModel)
            NfcRecordType.WIFI -> WifiRecordForm(viewModel)
            NfcRecordType.BLUETOOTH -> BluetoothRecordForm(viewModel)
            NfcRecordType.APP_LAUNCHER -> AppLauncherRecordForm(viewModel)
            NfcRecordType.PHONE -> PhoneRecordForm(viewModel)
            NfcRecordType.SMS -> SmsRecordForm(viewModel)
            NfcRecordType.EMAIL -> EmailRecordForm(viewModel)
            NfcRecordType.GEO -> GeoRecordForm(viewModel)
            NfcRecordType.CUSTOM_MIME -> CustomMimeRecordForm(viewModel)
            NfcRecordType.CUSTOM_EXTERNAL -> CustomExternalRecordForm(viewModel)
            NfcRecordType.RAW_HEX -> RawHexRecordForm(viewModel)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun UrlRecordForm(viewModel: NfcViewModel) {
    val config by viewModel.urlConfig.collectAsState()

    Column {
        FormTextField(
            label = "Website URL",
            value = config.url,
            onValueChange = { viewModel.urlConfig.value = config.copy(url = it) },
            placeholder = "https://example.com",
            keyboardType = KeyboardType.Uri
        )

        Spacer(modifier = Modifier.height(10.dp))
        Text("Quick Suffixes / Shortcuts:", style = MaterialTheme.typography.labelSmall, color = TextMuted)
        Spacer(modifier = Modifier.height(6.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val chips = listOf("https://", "https://github.com/", "https://linkedin.com/in/", ".com", ".org", ".io")
            chips.forEach { chip ->
                AssistChip(
                    onClick = {
                        val current = config.url
                        viewModel.urlConfig.value = if (chip.startsWith("http")) {
                            config.copy(url = chip)
                        } else {
                            config.copy(url = current + chip)
                        }
                    },
                    label = { Text(chip, style = MaterialTheme.typography.labelSmall) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = DarkSurfaceVariant,
                        labelColor = TextPrimary
                    )
                )
            }
        }
    }
}

@Composable
fun TextRecordForm(viewModel: NfcViewModel) {
    val config by viewModel.textConfig.collectAsState()

    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            FormTextField(
                label = "Language Code",
                value = config.languageCode,
                onValueChange = { viewModel.textConfig.value = config.copy(languageCode = it.take(5)) },
                placeholder = "en",
                modifier = Modifier.width(130.dp)
            )

            Row(
                modifier = Modifier
                    .weight(1f)
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = config.isUtf8,
                    onClick = { viewModel.textConfig.value = config.copy(isUtf8 = true) },
                    label = { Text("UTF-8") },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = CyanPrimary)
                )
                FilterChip(
                    selected = !config.isUtf8,
                    onClick = { viewModel.textConfig.value = config.copy(isUtf8 = false) },
                    label = { Text("UTF-16") },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = CyanPrimary)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        FormTextField(
            label = "Text Content",
            value = config.text,
            onValueChange = { viewModel.textConfig.value = config.copy(text = it) },
            placeholder = "Type notes, messages or instructions...",
            singleLine = false,
            minLines = 4
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Character count: ${config.text.length} (Estimated bytes: ~${config.text.toByteArray().size + 3})",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted
        )
    }
}

@Composable
fun VCardRecordForm(viewModel: NfcViewModel) {
    val config by viewModel.vCardConfig.collectAsState()

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FormTextField(
                label = "First Name",
                value = config.firstName,
                onValueChange = { viewModel.vCardConfig.value = config.copy(firstName = it) },
                placeholder = "John",
                modifier = Modifier.weight(1f)
            )
            FormTextField(
                label = "Last Name",
                value = config.lastName,
                onValueChange = { viewModel.vCardConfig.value = config.copy(lastName = it) },
                placeholder = "Doe",
                modifier = Modifier.weight(1f)
            )
        }

        FormTextField(
            label = "Phone Number",
            value = config.phone,
            onValueChange = { viewModel.vCardConfig.value = config.copy(phone = it) },
            placeholder = "+1 (555) 012-3456",
            keyboardType = KeyboardType.Phone
        )

        FormTextField(
            label = "Email Address",
            value = config.email,
            onValueChange = { viewModel.vCardConfig.value = config.copy(email = it) },
            placeholder = "john.doe@example.com",
            keyboardType = KeyboardType.Email
        )

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FormTextField(
                label = "Organization / Company",
                value = config.organization,
                onValueChange = { viewModel.vCardConfig.value = config.copy(organization = it) },
                placeholder = "Acme Corp",
                modifier = Modifier.weight(1f)
            )
            FormTextField(
                label = "Job Title",
                value = config.title,
                onValueChange = { viewModel.vCardConfig.value = config.copy(title = it) },
                placeholder = "Engineer",
                modifier = Modifier.weight(1f)
            )
        }

        FormTextField(
            label = "Website / Portfolio",
            value = config.website,
            onValueChange = { viewModel.vCardConfig.value = config.copy(website = it) },
            placeholder = "https://example.com",
            keyboardType = KeyboardType.Uri
        )

        FormTextField(
            label = "Physical Address",
            value = config.address,
            onValueChange = { viewModel.vCardConfig.value = config.copy(address = it) },
            placeholder = "123 Market St, San Francisco, CA"
        )

        FormTextField(
            label = "Note",
            value = config.note,
            onValueChange = { viewModel.vCardConfig.value = config.copy(note = it) },
            placeholder = "Met at Tech Summit 2026",
            singleLine = false,
            minLines = 2
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WifiRecordForm(viewModel: NfcViewModel) {
    val config by viewModel.wifiConfig.collectAsState()
    var passwordVisible by remember { mutableStateOf(false) }
    var expandedDropdown by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        FormTextField(
            label = "Network SSID",
            value = config.ssid,
            onValueChange = { viewModel.wifiConfig.value = config.copy(ssid = it) },
            placeholder = "MyHomeNetwork_5G"
        )

        // Auth Type Dropdown
        ExposedDropdownMenuBox(
            expanded = expandedDropdown,
            onExpandedChange = { expandedDropdown = !expandedDropdown }
        ) {
            OutlinedTextField(
                value = config.authType.label,
                onValueChange = {},
                readOnly = true,
                label = { Text("Authentication & Encryption") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDropdown) },
                colors = defaultTextFieldColors(),
                modifier = Modifier
                    .fillMaxWidth()
                    .menuAnchor()
            )
            ExposedDropdownMenu(
                expanded = expandedDropdown,
                onDismissRequest = { expandedDropdown = false },
                modifier = Modifier.background(DarkSurfaceVariant)
            ) {
                WifiAuthType.values().forEach { auth ->
                    DropdownMenuItem(
                        text = { Text(auth.label, color = TextPrimary) },
                        onClick = {
                            viewModel.wifiConfig.value = config.copy(authType = auth)
                            expandedDropdown = false
                        }
                    )
                }
            }
        }

        if (config.authType != WifiAuthType.OPEN) {
            OutlinedTextField(
                value = config.password,
                onValueChange = { viewModel.wifiConfig.value = config.copy(password = it) },
                label = { Text("Network Password / Key") },
                placeholder = { Text("Enter Wi-Fi password") },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = null,
                            tint = TextSecondary
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                colors = defaultTextFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Hidden Network", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                Text("SSID does not broadcast", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            }
            Switch(
                checked = config.isHidden,
                onCheckedChange = { viewModel.wifiConfig.value = config.copy(isHidden = it) },
                colors = SwitchDefaults.colors(checkedThumbColor = CyanPrimary)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("NFC Forum WSC Binary Format", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                Text("Standard Wi-Fi Simple Configuration MIME payload", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            }
            Switch(
                checked = config.useWscBinary,
                onCheckedChange = { viewModel.wifiConfig.value = config.copy(useWscBinary = it) },
                colors = SwitchDefaults.colors(checkedThumbColor = CyanPrimary)
            )
        }
    }
}

@Composable
fun BluetoothRecordForm(viewModel: NfcViewModel) {
    val config by viewModel.bluetoothConfig.collectAsState()

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        FormTextField(
            label = "Device Name",
            value = config.deviceName,
            onValueChange = { viewModel.bluetoothConfig.value = config.copy(deviceName = it) },
            placeholder = "Wireless Headphones / Car Audio"
        )

        FormTextField(
            label = "Bluetooth MAC Address",
            value = config.macAddress,
            onValueChange = { viewModel.bluetoothConfig.value = config.copy(macAddress = it) },
            placeholder = "00:11:22:33:44:55",
            keyboardType = KeyboardType.Ascii
        )
        Text(
            text = "Enter standard 6-byte hexadecimal MAC address (colons or dashes optional)",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AppLauncherRecordForm(viewModel: NfcViewModel) {
    val config by viewModel.appLauncherConfig.collectAsState()

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        FormTextField(
            label = "Android Package Name",
            value = config.packageName,
            onValueChange = { viewModel.appLauncherConfig.value = config.copy(packageName = it) },
            placeholder = "com.google.android.youtube"
        )

        Text("Popular App Presets:", style = MaterialTheme.typography.labelSmall, color = TextMuted)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val apps = listOf(
                "YouTube" to "com.google.android.youtube",
                "Spotify" to "com.spotify.music",
                "Google Maps" to "com.google.android.apps.maps",
                "WhatsApp" to "com.whatsapp",
                "Chrome" to "com.android.chrome",
                "Instagram" to "com.instagram.android",
                "Telegram" to "org.telegram.messenger",
                "Twitter / X" to "com.twitter.android"
            )
            apps.forEach { (name, pkg) ->
                AssistChip(
                    onClick = { viewModel.appLauncherConfig.value = config.copy(packageName = pkg) },
                    label = { Text(name, style = MaterialTheme.typography.labelSmall) },
                    colors = AssistChipDefaults.assistChipColors(containerColor = DarkSurfaceVariant, labelColor = TextPrimary)
                )
            }
        }
    }
}

@Composable
fun PhoneRecordForm(viewModel: NfcViewModel) {
    val config by viewModel.phoneConfig.collectAsState()

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        FormTextField(
            label = "Phone Number",
            value = config.phoneNumber,
            onValueChange = { viewModel.phoneConfig.value = config.copy(phoneNumber = it) },
            placeholder = "+1 800 555 0199",
            keyboardType = KeyboardType.Phone
        )
        Text(
            text = "Tapping tag triggers dialer with this number pre-filled.",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted
        )
    }
}

@Composable
fun SmsRecordForm(viewModel: NfcViewModel) {
    val config by viewModel.smsConfig.collectAsState()

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        FormTextField(
            label = "Recipient Phone Number",
            value = config.phoneNumber,
            onValueChange = { viewModel.smsConfig.value = config.copy(phoneNumber = it) },
            placeholder = "+1 555 0199",
            keyboardType = KeyboardType.Phone
        )

        FormTextField(
            label = "Pre-filled Message Body",
            value = config.messageBody,
            onValueChange = { viewModel.smsConfig.value = config.copy(messageBody = it) },
            placeholder = "I have arrived at the location.",
            singleLine = false,
            minLines = 3
        )
    }
}

@Composable
fun EmailRecordForm(viewModel: NfcViewModel) {
    val config by viewModel.emailConfig.collectAsState()

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        FormTextField(
            label = "Recipient Email",
            value = config.emailAddress,
            onValueChange = { viewModel.emailConfig.value = config.copy(emailAddress = it) },
            placeholder = "contact@example.com",
            keyboardType = KeyboardType.Email
        )

        FormTextField(
            label = "Subject Line",
            value = config.subject,
            onValueChange = { viewModel.emailConfig.value = config.copy(subject = it) },
            placeholder = "Project Inquiry / Follow-up"
        )

        FormTextField(
            label = "Message Body",
            value = config.body,
            onValueChange = { viewModel.emailConfig.value = config.copy(body = it) },
            placeholder = "Hello,\nI would like to discuss...",
            singleLine = false,
            minLines = 3
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GeoRecordForm(viewModel: NfcViewModel) {
    val config by viewModel.geoConfig.collectAsState()

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FormTextField(
                label = "Latitude",
                value = if (config.latitude == 0.0) "" else config.latitude.toString(),
                onValueChange = {
                    val lat = it.toDoubleOrNull() ?: 0.0
                    viewModel.geoConfig.value = config.copy(latitude = lat)
                },
                placeholder = "37.7749",
                keyboardType = KeyboardType.Decimal,
                modifier = Modifier.weight(1f)
            )

            FormTextField(
                label = "Longitude",
                value = if (config.longitude == 0.0) "" else config.longitude.toString(),
                onValueChange = {
                    val lng = it.toDoubleOrNull() ?: 0.0
                    viewModel.geoConfig.value = config.copy(longitude = lng)
                },
                placeholder = "-122.4194",
                keyboardType = KeyboardType.Decimal,
                modifier = Modifier.weight(1f)
            )
        }

        FormTextField(
            label = "Location Label / Query (Optional)",
            value = config.label,
            onValueChange = { viewModel.geoConfig.value = config.copy(label = it) },
            placeholder = "San Francisco City Hall"
        )

        Text("Quick City Presets:", style = MaterialTheme.typography.labelSmall, color = TextMuted)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val cities = listOf(
                "San Francisco" to Pair(37.7749, -122.4194),
                "New York" to Pair(40.7128, -74.0060),
                "London" to Pair(51.5074, -0.1278),
                "Tokyo" to Pair(35.6762, 139.6503),
                "Paris" to Pair(48.8566, 2.3522)
            )
            cities.forEach { (cityName, coords) ->
                AssistChip(
                    onClick = {
                        viewModel.geoConfig.value = config.copy(
                            latitude = coords.first,
                            longitude = coords.second,
                            label = cityName
                        )
                    },
                    label = { Text(cityName, style = MaterialTheme.typography.labelSmall) },
                    colors = AssistChipDefaults.assistChipColors(containerColor = DarkSurfaceVariant, labelColor = TextPrimary)
                )
            }
        }
    }
}

@Composable
fun CustomMimeRecordForm(viewModel: NfcViewModel) {
    val config by viewModel.customMimeConfig.collectAsState()

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        FormTextField(
            label = "MIME Media Type",
            value = config.mimeType,
            onValueChange = { viewModel.customMimeConfig.value = config.copy(mimeType = it) },
            placeholder = "application/json"
        )

        FormTextField(
            label = "Payload Data",
            value = config.payload,
            onValueChange = { viewModel.customMimeConfig.value = config.copy(payload = it) },
            placeholder = "{\"key\": \"value\"}",
            singleLine = false,
            minLines = 4,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun CustomExternalRecordForm(viewModel: NfcViewModel) {
    val config by viewModel.customExternalConfig.collectAsState()

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FormTextField(
                label = "Domain",
                value = config.domain,
                onValueChange = { viewModel.customExternalConfig.value = config.copy(domain = it) },
                placeholder = "mycompany.com",
                modifier = Modifier.weight(1f)
            )

            FormTextField(
                label = "Record Type",
                value = config.recordType,
                onValueChange = { viewModel.customExternalConfig.value = config.copy(recordType = it) },
                placeholder = "doorKey",
                modifier = Modifier.weight(1f)
            )
        }

        FormTextField(
            label = "Payload Data",
            value = config.payload,
            onValueChange = { viewModel.customExternalConfig.value = config.copy(payload = it) },
            placeholder = "Payload bytes / string",
            singleLine = false,
            minLines = 3,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = "Creates URN: urn:nfc:ext:${config.domain}:${config.recordType}",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun RawHexRecordForm(viewModel: NfcViewModel) {
    val config by viewModel.rawHexConfig.collectAsState()

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FormTextField(
                label = "TNF (0-7)",
                value = config.tnf.toString(),
                onValueChange = {
                    val s = it.toShortOrNull() ?: 1
                    viewModel.rawHexConfig.value = config.copy(tnf = s)
                },
                placeholder = "1",
                keyboardType = KeyboardType.Number,
                modifier = Modifier.width(90.dp)
            )

            FormTextField(
                label = "Type (Hex)",
                value = config.typeHex,
                onValueChange = { viewModel.rawHexConfig.value = config.copy(typeHex = it) },
                placeholder = "55",
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.weight(1f)
            )

            FormTextField(
                label = "ID (Hex)",
                value = config.idHex,
                onValueChange = { viewModel.rawHexConfig.value = config.copy(idHex = it) },
                placeholder = "Optional",
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.weight(1f)
            )
        }

        FormTextField(
            label = "Payload (Hex)",
            value = config.payloadHex,
            onValueChange = { viewModel.rawHexConfig.value = config.copy(payloadHex = it) },
            placeholder = "04 67 6F 6F 67 6C 65 2E 63 6F 6D",
            singleLine = false,
            minLines = 3,
            fontFamily = FontFamily.Monospace
        )

        val byteCount = (config.payloadHex.replace(" ", "").length + 1) / 2
        Text(
            text = "Total Payload Size: ~$byteCount bytes",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted
        )
    }
}

@Composable
fun FormTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String = "",
    singleLine: Boolean = true,
    minLines: Int = 1,
    keyboardType: KeyboardType = KeyboardType.Text,
    fontFamily: FontFamily = FontFamily.Default,
    modifier: Modifier = Modifier.fillMaxWidth()
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        placeholder = { Text(placeholder, color = TextMuted) },
        singleLine = singleLine,
        minLines = minLines,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        colors = defaultTextFieldColors(),
        textStyle = MaterialTheme.typography.bodyLarge.copy(color = TextPrimary, fontFamily = fontFamily),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    )
}

@Composable
fun defaultTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = CyanPrimary,
    unfocusedBorderColor = DarkOutline,
    focusedLabelColor = CyanPrimary,
    unfocusedLabelColor = TextSecondary,
    focusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.5f),
    unfocusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.25f)
)
