package com.example.nfcwriter.model

/**
 * Pre-defined or saved preset configuration.
 */
data class PresetTemplate(
    val id: String,
    val title: String,
    val description: String,
    val records: List<NfcRecordConfig>,
    val options: WriteOptions = WriteOptions()
)

object PresetDefaults {
    val templates: List<PresetTemplate> = listOf(
        PresetTemplate(
            id = "tpl_biz_card",
            title = "Digital Business Card",
            description = "Complete vCard with name, company, phone, email & website",
            records = listOf(
                NfcRecordConfig.VCard(
                    firstName = "Alex",
                    lastName = "Morgan",
                    organization = "Cybernetics Corp",
                    title = "Lead Architect",
                    phone = "+1 (555) 019-2834",
                    email = "alex.morgan@example.com",
                    website = "https://example.com/portfolio",
                    address = "742 Evergreen Terrace, Springfield",
                    note = "Tap to connect"
                ),
                NfcRecordConfig.Url(
                    url = "https://linkedin.com"
                )
            )
        ),
        PresetTemplate(
            id = "tpl_guest_wifi",
            title = "Guest Wi-Fi Hotspot",
            description = "Instant connection to guest wireless network without typing passwords",
            records = listOf(
                NfcRecordConfig.Wifi(
                    ssid = "Guest_WiFi_5G",
                    password = "WelcomeGuest2026",
                    authType = WifiAuthType.WPA2_PSK,
                    isHidden = false,
                    useWscBinary = true
                )
            )
        ),
        PresetTemplate(
            id = "tpl_emergency",
            title = "Emergency Medical & Contact (ICE)",
            description = "Direct telephone dialer and SMS with emergency contact details",
            records = listOf(
                NfcRecordConfig.Phone(phoneNumber = "+1911"),
                NfcRecordConfig.Text(
                    text = "Blood Type: O+ | Allergies: Penicillin | ICE Contact: Jane Doe (+1-555-0199)",
                    languageCode = "en"
                )
            )
        ),
        PresetTemplate(
            id = "tpl_smart_home",
            title = "Smart Home Automation Trigger",
            description = "Custom JSON payload for Home Assistant, Tasker or Node-RED",
            records = listOf(
                NfcRecordConfig.CustomMime(
                    mimeType = "application/json",
                    payload = "{\"action\": \"toggle_living_room_lights\", \"scene\": \"movie_night\", \"brightness\": 40}"
                )
            )
        ),
        PresetTemplate(
            id = "tpl_app_launcher",
            title = "App Launcher (YouTube)",
            description = "Instructs phone to open YouTube app immediately or open Play Store",
            records = listOf(
                NfcRecordConfig.AppLauncher(
                    packageName = "com.google.android.youtube"
                )
            )
        ),
        PresetTemplate(
            id = "tpl_geo_pin",
            title = "Meeting Point Pin",
            description = "Geo coordinate tag that opens directly in Google Maps or navigation",
            records = listOf(
                NfcRecordConfig.Geo(
                    latitude = 37.78825,
                    longitude = -122.4324,
                    label = "Conference Venue Main Hall"
                )
            )
        )
    )
}
