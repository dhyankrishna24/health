package com.example.nfcwriter.ui.viewmodel

import android.nfc.Tag
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.nfcwriter.model.NfcRecordConfig
import com.example.nfcwriter.model.NfcRecordType
import com.example.nfcwriter.model.PresetDefaults
import com.example.nfcwriter.model.PresetTemplate
import com.example.nfcwriter.model.TagInfo
import com.example.nfcwriter.model.WifiAuthType
import com.example.nfcwriter.model.WriteOptions
import com.example.nfcwriter.nfc.NfcManager
import com.example.nfcwriter.nfc.NfcWriteException
import com.example.nfcwriter.nfc.PayloadBuilders
import com.example.nfcwriter.nfc.WriteResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class AppTab {
    WRITE,
    MULTI_RECORD,
    INSPECT,
    PRESETS
}

sealed class WriteDialogState {
    object Closed : WriteDialogState()
    data class WaitingForTag(
        val summary: String,
        val payloadSizeBytes: Int,
        val isPermanentLock: Boolean
    ) : WriteDialogState()
    object Writing : WriteDialogState()
    data class Success(val result: WriteResult) : WriteDialogState()
    data class Error(val message: String) : WriteDialogState()
}

sealed class UiEvent {
    object SuccessHaptic : UiEvent()
    object ErrorHaptic : UiEvent()
    data class ShowToast(val message: String) : UiEvent()
}

class NfcViewModel : ViewModel() {

    private val _currentTab = MutableStateFlow(AppTab.WRITE)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    private val _selectedRecordType = MutableStateFlow(NfcRecordType.URL)
    val selectedRecordType: StateFlow<NfcRecordType> = _selectedRecordType.asStateFlow()

    // Individual record configurations
    var urlConfig = MutableStateFlow(NfcRecordConfig.Url())
    var textConfig = MutableStateFlow(NfcRecordConfig.Text())
    var vCardConfig = MutableStateFlow(NfcRecordConfig.VCard())
    var wifiConfig = MutableStateFlow(NfcRecordConfig.Wifi())
    var bluetoothConfig = MutableStateFlow(NfcRecordConfig.Bluetooth())
    var appLauncherConfig = MutableStateFlow(NfcRecordConfig.AppLauncher())
    var phoneConfig = MutableStateFlow(NfcRecordConfig.Phone())
    var smsConfig = MutableStateFlow(NfcRecordConfig.Sms())
    var emailConfig = MutableStateFlow(NfcRecordConfig.Email())
    var geoConfig = MutableStateFlow(NfcRecordConfig.Geo())
    var customMimeConfig = MutableStateFlow(NfcRecordConfig.CustomMime())
    var customExternalConfig = MutableStateFlow(NfcRecordConfig.CustomExternal())
    var rawHexConfig = MutableStateFlow(NfcRecordConfig.RawHex())

    // Multi-record queue
    private val _multiRecordQueue = MutableStateFlow<List<NfcRecordConfig>>(emptyList())
    val multiRecordQueue: StateFlow<List<NfcRecordConfig>> = _multiRecordQueue.asStateFlow()

    // Write options
    private val _writeOptions = MutableStateFlow(WriteOptions())
    val writeOptions: StateFlow<WriteOptions> = _writeOptions.asStateFlow()

    // Write modal dialog state
    private val _writeDialogState = MutableStateFlow<WriteDialogState>(WriteDialogState.Closed)
    val writeDialogState: StateFlow<WriteDialogState> = _writeDialogState.asStateFlow()

    // Scanned tag info for inspector
    private val _lastInspectedTag = MutableStateFlow<TagInfo?>(null)
    val lastInspectedTag: StateFlow<TagInfo?> = _lastInspectedTag.asStateFlow()

    // Presets list
    private val _presets = MutableStateFlow<List<PresetTemplate>>(PresetDefaults.templates)
    val presets: StateFlow<List<PresetTemplate>> = _presets.asStateFlow()

    private val _uiEvents = MutableSharedFlow<UiEvent>()
    val uiEvents: SharedFlow<UiEvent> = _uiEvents.asSharedFlow()

    fun setTab(tab: AppTab) {
        _currentTab.value = tab
    }

    fun selectRecordType(type: NfcRecordType) {
        _selectedRecordType.value = type
    }

    fun updateWriteOptions(transform: (WriteOptions) -> WriteOptions) {
        _writeOptions.value = transform(_writeOptions.value)
    }

    fun getCurrentActiveRecord(): NfcRecordConfig {
        return when (_selectedRecordType.value) {
            NfcRecordType.URL -> urlConfig.value
            NfcRecordType.TEXT -> textConfig.value
            NfcRecordType.VCARD -> vCardConfig.value
            NfcRecordType.WIFI -> wifiConfig.value
            NfcRecordType.BLUETOOTH -> bluetoothConfig.value
            NfcRecordType.APP_LAUNCHER -> appLauncherConfig.value
            NfcRecordType.PHONE -> phoneConfig.value
            NfcRecordType.SMS -> smsConfig.value
            NfcRecordType.EMAIL -> emailConfig.value
            NfcRecordType.GEO -> geoConfig.value
            NfcRecordType.CUSTOM_MIME -> customMimeConfig.value
            NfcRecordType.CUSTOM_EXTERNAL -> customExternalConfig.value
            NfcRecordType.RAW_HEX -> rawHexConfig.value
        }
    }

    fun addCurrentRecordToQueue() {
        val current = getCurrentActiveRecord()
        _multiRecordQueue.value = _multiRecordQueue.value + current
        viewModelScope.launch {
            _uiEvents.emit(UiEvent.ShowToast("Added ${current.type.title} to multi-record queue!"))
        }
    }

    fun removeRecordFromQueue(index: Int) {
        val list = _multiRecordQueue.value.toMutableList()
        if (index in list.indices) {
            list.removeAt(index)
            _multiRecordQueue.value = list
        }
    }

    fun clearQueue() {
        _multiRecordQueue.value = emptyList()
    }

    fun startSingleWrite() {
        val record = getCurrentActiveRecord()
        val records = listOf(record)
        val msg = PayloadBuilders.buildNdefMessage(records, _writeOptions.value)
        _writeDialogState.value = WriteDialogState.WaitingForTag(
            summary = "${record.type.title}: ${record.summary()}",
            payloadSizeBytes = msg.byteArrayLength,
            isPermanentLock = _writeOptions.value.makeReadOnly
        )
    }

    fun startMultiRecordWrite() {
        val records = _multiRecordQueue.value
        if (records.isEmpty()) {
            viewModelScope.launch {
                _uiEvents.emit(UiEvent.ShowToast("Please add at least one record to the queue."))
            }
            return
        }
        val msg = PayloadBuilders.buildNdefMessage(records, _writeOptions.value)
        _writeDialogState.value = WriteDialogState.WaitingForTag(
            summary = "Multi-Record (${records.size} items: ${records.joinToString { it.type.title }})",
            payloadSizeBytes = msg.byteArrayLength,
            isPermanentLock = _writeOptions.value.makeReadOnly
        )
    }

    fun closeWriteDialog() {
        _writeDialogState.value = WriteDialogState.Closed
    }

    fun loadPreset(preset: PresetTemplate) {
        if (preset.records.size == 1) {
            val record = preset.records.first()
            _selectedRecordType.value = record.type
            applyRecordToState(record)
            _currentTab.value = AppTab.WRITE
        } else {
            _multiRecordQueue.value = preset.records
            _currentTab.value = AppTab.MULTI_RECORD
        }
        _writeOptions.value = preset.options
        viewModelScope.launch {
            _uiEvents.emit(UiEvent.ShowToast("Loaded preset: ${preset.title}"))
        }
    }

    private fun applyRecordToState(record: NfcRecordConfig) {
        when (record) {
            is NfcRecordConfig.Url -> urlConfig.value = record
            is NfcRecordConfig.Text -> textConfig.value = record
            is NfcRecordConfig.VCard -> vCardConfig.value = record
            is NfcRecordConfig.Wifi -> wifiConfig.value = record
            is NfcRecordConfig.Bluetooth -> bluetoothConfig.value = record
            is NfcRecordConfig.AppLauncher -> appLauncherConfig.value = record
            is NfcRecordConfig.Phone -> phoneConfig.value = record
            is NfcRecordConfig.Sms -> smsConfig.value = record
            is NfcRecordConfig.Email -> emailConfig.value = record
            is NfcRecordConfig.Geo -> geoConfig.value = record
            is NfcRecordConfig.CustomMime -> customMimeConfig.value = record
            is NfcRecordConfig.CustomExternal -> customExternalConfig.value = record
            is NfcRecordConfig.RawHex -> rawHexConfig.value = record
        }
    }

    fun saveCurrentAsPreset(title: String, description: String) {
        val currentRecords = if (_currentTab.value == AppTab.MULTI_RECORD && _multiRecordQueue.value.isNotEmpty()) {
            _multiRecordQueue.value
        } else {
            listOf(getCurrentActiveRecord())
        }

        val newPreset = PresetTemplate(
            id = "custom_${System.currentTimeMillis()}",
            title = title.ifBlank { "Custom Preset" },
            description = description.ifBlank { "Saved on ${java.text.SimpleDateFormat.getDateInstance().format(java.util.Date())}" },
            records = currentRecords,
            options = _writeOptions.value
        )
        _presets.value = listOf(newPreset) + _presets.value
        viewModelScope.launch {
            _uiEvents.emit(UiEvent.ShowToast("Preset saved!"))
        }
    }

    /**
     * Entry point when an NFC tag is detected on the device.
     */
    fun onTagDiscovered(tag: Tag) {
        val currentState = _writeDialogState.value

        if (currentState is WriteDialogState.WaitingForTag) {
            // Write Mode
            _writeDialogState.value = WriteDialogState.Writing
            viewModelScope.launch {
                try {
                    val records = if (_currentTab.value == AppTab.MULTI_RECORD) {
                        _multiRecordQueue.value
                    } else {
                        listOf(getCurrentActiveRecord())
                    }
                    val options = _writeOptions.value
                    val message = PayloadBuilders.buildNdefMessage(records, options)

                    val result = withContext(Dispatchers.IO) {
                        NfcManager.writeTag(tag, message, options)
                    }

                    _writeDialogState.value = WriteDialogState.Success(result)
                    _uiEvents.emit(UiEvent.SuccessHaptic)
                } catch (e: Exception) {
                    val errorMsg = when (e) {
                        is NfcWriteException -> e.message ?: "NFC Write error"
                        else -> "Failed to write: ${e.localizedMessage ?: "Unknown error"}"
                    }
                    _writeDialogState.value = WriteDialogState.Error(errorMsg)
                    _uiEvents.emit(UiEvent.ErrorHaptic)
                }
            }
        } else {
            // Reader / Inspector Mode
            viewModelScope.launch {
                try {
                    val tagInfo = withContext(Dispatchers.IO) {
                        NfcManager.inspectTag(tag)
                    }
                    _lastInspectedTag.value = tagInfo
                    _currentTab.value = AppTab.INSPECT
                    _uiEvents.emit(UiEvent.SuccessHaptic)
                    _uiEvents.emit(UiEvent.ShowToast("Tag inspected: ${tagInfo.uidHex}"))
                } catch (e: Exception) {
                    _uiEvents.emit(UiEvent.ErrorHaptic)
                    _uiEvents.emit(UiEvent.ShowToast("Failed to read tag: ${e.localizedMessage}"))
                }
            }
        }
    }
}
