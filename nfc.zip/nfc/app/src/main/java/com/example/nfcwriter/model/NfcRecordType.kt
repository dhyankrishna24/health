package com.example.nfcwriter.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.ContactPhone
import androidx.compose.material.icons.filled.DataArray
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Enumeration of all supported NFC record types.
 */
enum class NfcRecordType(
    val title: String,
    val subtitle: String,
    val icon: ImageVector
) {
    URL(
        title = "Website / URL",
        subtitle = "Open links, social profiles, web apps",
        icon = Icons.Default.Link
    ),
    TEXT(
        title = "Text",
        subtitle = "Plain text, notes, messages with language encoding",
        icon = Icons.Default.TextFields
    ),
    VCARD(
        title = "Contact (vCard)",
        subtitle = "Digital business card with phone, email, info",
        icon = Icons.Default.ContactPhone
    ),
    WIFI(
        title = "Wi-Fi Network",
        subtitle = "Auto-connect to Wi-Fi (WPA2/WPA3/Open)",
        icon = Icons.Default.Wifi
    ),
    BLUETOOTH(
        title = "Bluetooth Device",
        subtitle = "Pair Bluetooth peripherals with OOB record",
        icon = Icons.Default.Bluetooth
    ),
    APP_LAUNCHER(
        title = "App Launcher (AAR)",
        subtitle = "Launch an Android app or open Play Store",
        icon = Icons.Default.Android
    ),
    PHONE(
        title = "Phone Call",
        subtitle = "Dial a phone number instantly",
        icon = Icons.Default.Phone
    ),
    SMS(
        title = "SMS Message",
        subtitle = "Send pre-filled SMS to a recipient",
        icon = Icons.Default.Sms
    ),
    EMAIL(
        title = "Email",
        subtitle = "Send pre-filled email with subject and body",
        icon = Icons.Default.AlternateEmail
    ),
    GEO(
        title = "Location (Geo)",
        subtitle = "GPS coordinates or Google Maps pin",
        icon = Icons.Default.LocationOn
    ),
    CUSTOM_MIME(
        title = "Custom MIME",
        subtitle = "Custom MIME-type (e.g. application/json)",
        icon = Icons.Default.Extension
    ),
    CUSTOM_EXTERNAL(
        title = "External Type",
        subtitle = "NFC Forum external record (urn:nfc:ext:domain:type)",
        icon = Icons.Default.Language
    ),
    RAW_HEX(
        title = "Raw Hex / Custom Payload",
        subtitle = "Direct byte payload in hexadecimal",
        icon = Icons.Default.DataArray
    )
}
