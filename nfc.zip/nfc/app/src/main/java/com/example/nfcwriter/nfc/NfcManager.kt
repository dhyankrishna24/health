package com.example.nfcwriter.nfc

import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.nfc.tech.NdefFormatable
import com.example.nfcwriter.model.ParsedRecordInfo
import com.example.nfcwriter.model.TagInfo
import com.example.nfcwriter.model.WriteOptions
import java.io.IOException
import java.nio.charset.StandardCharsets

data class WriteResult(
    val success: Boolean,
    val uidHex: String,
    val bytesWritten: Int,
    val isLockedReadOnly: Boolean,
    val durationMs: Long,
    val message: String
)

sealed class NfcWriteException(message: String) : Exception(message) {
    class TagReadOnly(message: String = "Card is permanently locked / read-only.") : NfcWriteException(message)
    class CapacityExceeded(message: String) : NfcWriteException(message)
    class FormattingNotSupported(message: String) : NfcWriteException(message)
    class ConnectionLost(message: String = "Connection lost. Please hold card steady against the device.") : NfcWriteException(message)
    class LockFailed(message: String = "Failed to lock card as read-only. Chip does not support locking.") : NfcWriteException(message)
}

object NfcManager {

    /**
     * Writes an NdefMessage to the detected NFC tag with the configured options.
     */
    fun writeTag(tag: Tag, message: NdefMessage, options: WriteOptions): WriteResult {
        val startTime = System.currentTimeMillis()
        val uid = tag.id ?: ByteArray(0)
        val uidHex = PayloadBuilders.bytesToHex(uid)
        val messageSize = message.byteArrayLength
        var wasLocked = false

        val ndef = Ndef.get(tag)
        if (ndef != null) {
            try {
                ndef.connect()

                if (!ndef.isWritable) {
                    throw NfcWriteException.TagReadOnly("NFC Tag is marked as Read-Only. Writing is not permitted.")
                }

                val maxSize = ndef.maxSize
                if (messageSize > maxSize) {
                    throw NfcWriteException.CapacityExceeded(
                        "Payload size ($messageSize bytes) exceeds tag maximum capacity ($maxSize bytes)."
                    )
                }

                // Write the message
                ndef.writeNdefMessage(message)

                // Permanent Lock / Read-Only option
                if (options.makeReadOnly) {
                    if (ndef.canMakeReadOnly()) {
                        val locked = ndef.makeReadOnly()
                        if (!locked) {
                            throw NfcWriteException.LockFailed("Chip rejected makeReadOnly command.")
                        }
                        wasLocked = true
                    } else {
                        throw NfcWriteException.LockFailed("This NFC chip cannot be made read-only via standard NDEF command.")
                    }
                }

                val duration = System.currentTimeMillis() - startTime
                return WriteResult(
                    success = true,
                    uidHex = uidHex,
                    bytesWritten = messageSize,
                    isLockedReadOnly = wasLocked,
                    durationMs = duration,
                    message = if (wasLocked) "Successfully written & permanently locked!" else "Successfully written to card!"
                )
            } catch (e: IOException) {
                throw NfcWriteException.ConnectionLost("Tag was moved or lost connection: ${e.localizedMessage}")
            } finally {
                try {
                    if (ndef.isConnected) ndef.close()
                } catch (_: Exception) {}
            }
        } else {
            // Unformatted tag: Attempt format if enabled
            if (!options.formatIfUnformatted) {
                throw NfcWriteException.FormattingNotSupported("Tag is not NDEF formatted and auto-format is disabled.")
            }

            val formatable = NdefFormatable.get(tag)
                ?: throw NfcWriteException.FormattingNotSupported(
                    "Tag does not support NDEF formatable technology. Techs: ${tag.techList.joinToString { it.substringAfterLast('.') }}"
                )

            try {
                formatable.connect()
                if (options.makeReadOnly) {
                    formatable.formatReadOnly(message)
                    wasLocked = true
                } else {
                    formatable.format(message)
                }

                val duration = System.currentTimeMillis() - startTime
                return WriteResult(
                    success = true,
                    uidHex = uidHex,
                    bytesWritten = messageSize,
                    isLockedReadOnly = wasLocked,
                    durationMs = duration,
                    message = if (wasLocked) "Formatted, written, & permanently locked!" else "Tag successfully formatted & written!"
                )
            } catch (e: IOException) {
                throw NfcWriteException.ConnectionLost("Lost connection during tag formatting: ${e.localizedMessage}")
            } finally {
                try {
                    if (formatable.isConnected) formatable.close()
                } catch (_: Exception) {}
            }
        }
    }

    /**
     * Inspects an NFC Tag and returns complete technical details and parsed contents.
     */
    fun inspectTag(tag: Tag): TagInfo {
        val uid = tag.id ?: ByteArray(0)
        val uidHex = PayloadBuilders.bytesToHex(uid)
        val uidDec = if (uid.isNotEmpty()) {
            var decVal: Long = 0
            for (b in uid) {
                decVal = (decVal shl 8) or (b.toLong() and 0xFF)
            }
            decVal.toString()
        } else {
            "0"
        }

        val techList = tag.techList.map { it.substringAfterLast('.') }
        val ndef = Ndef.get(tag)

        if (ndef != null) {
            var isWritable = false
            var canMakeReadOnly = false
            var maxSize = 0
            var currentSize = 0
            var ndefType = "Unknown NDEF"
            val parsedRecords = mutableListOf<ParsedRecordInfo>()

            try {
                ndef.connect()
                isWritable = ndef.isWritable
                canMakeReadOnly = ndef.canMakeReadOnly()
                maxSize = ndef.maxSize
                ndefType = ndef.type ?: "NDEF"

                val msg = ndef.cachedNdefMessage ?: ndef.ndefMessage
                if (msg != null) {
                    currentSize = msg.byteArrayLength
                    msg.records.forEachIndexed { index, record ->
                        parsedRecords.add(parseRecord(index + 1, record))
                    }
                }
            } catch (_: Exception) {
                // If tag lost or protected, try cached info
                try {
                    val cachedMsg = ndef.cachedNdefMessage
                    if (cachedMsg != null) {
                        currentSize = cachedMsg.byteArrayLength
                        cachedMsg.records.forEachIndexed { index, record ->
                            parsedRecords.add(parseRecord(index + 1, record))
                        }
                    }
                } catch (_: Exception) {}
            } finally {
                try {
                    if (ndef.isConnected) ndef.close()
                } catch (_: Exception) {}
            }

            return TagInfo(
                uidHex = uidHex,
                uidDec = uidDec,
                techList = techList,
                isNdefFormatted = true,
                ndefType = ndefType,
                isWritable = isWritable,
                canMakeReadOnly = canMakeReadOnly,
                maxSize = maxSize,
                currentSize = currentSize,
                records = parsedRecords
            )
        } else {
            // Not formatted as NDEF
            val isFormatable = NdefFormatable.get(tag) != null
            return TagInfo(
                uidHex = uidHex,
                uidDec = uidDec,
                techList = techList,
                isNdefFormatted = false,
                ndefType = if (isFormatable) "Unformatted (NDEF Formatable)" else "Raw / Proprietary Tag",
                isWritable = isFormatable,
                canMakeReadOnly = false,
                maxSize = 0,
                currentSize = 0,
                records = emptyList()
            )
        }
    }

    private fun parseRecord(index: Int, record: NdefRecord): ParsedRecordInfo {
        val tnfStr = when (record.tnf) {
            NdefRecord.TNF_WELL_KNOWN -> "Well-Known"
            NdefRecord.TNF_MIME_MEDIA -> "MIME Media"
            NdefRecord.TNF_ABSOLUTE_URI -> "Absolute URI"
            NdefRecord.TNF_EXTERNAL_TYPE -> "External Type"
            NdefRecord.TNF_UNKNOWN -> "Unknown"
            NdefRecord.TNF_UNCHANGED -> "Unchanged"
            NdefRecord.TNF_EMPTY -> "Empty"
            else -> "TNF ${record.tnf}"
        }

        val typeStr = String(record.type, StandardCharsets.UTF_8)
        val idStr = if (record.id != null && record.id.isNotEmpty()) PayloadBuilders.bytesToHex(record.id) else "None"
        val payload = record.payload ?: ByteArray(0)

        val preview = when {
            record.tnf == NdefRecord.TNF_WELL_KNOWN && record.type.contentEquals(NdefRecord.RTD_URI) -> {
                try {
                    record.toUri()?.toString() ?: "URI Record"
                } catch (_: Exception) {
                    "URI [Raw: ${payload.size} bytes]"
                }
            }
            record.tnf == NdefRecord.TNF_WELL_KNOWN && record.type.contentEquals(NdefRecord.RTD_TEXT) -> {
                decodeTextRecord(payload)
            }
            record.tnf == NdefRecord.TNF_MIME_MEDIA -> {
                val mime = typeStr
                val textPreview = String(payload.take(100).toByteArray(), StandardCharsets.UTF_8)
                "[$mime] $textPreview"
            }
            else -> {
                val printable = String(payload.take(80).toByteArray(), StandardCharsets.UTF_8)
                if (printable.all { it.code in 32..126 || it == '\n' || it == '\r' }) {
                    printable
                } else {
                    "Hex: ${PayloadBuilders.bytesToHex(payload.take(24).toByteArray(), " ")}..."
                }
            }
        }

        return ParsedRecordInfo(
            index = index,
            tnf = tnfStr,
            type = typeStr,
            id = idStr,
            payloadPreview = preview,
            sizeBytes = payload.size
        )
    }

    private fun decodeTextRecord(payload: ByteArray): String {
        if (payload.isEmpty()) return ""
        val status = payload[0].toInt()
        val isUtf8 = (status and 0x80) == 0
        val langLen = status and 0x3F
        val charset = if (isUtf8) StandardCharsets.UTF_8 else StandardCharsets.UTF_16

        return try {
            val lang = String(payload, 1, langLen, StandardCharsets.US_ASCII)
            val text = String(payload, 1 + langLen, payload.size - 1 - langLen, charset)
            "($lang) $text"
        } catch (_: Exception) {
            "Text Record (${payload.size} bytes)"
        }
    }
}
