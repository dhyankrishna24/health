package com.example.nfcwriter.ui.theme

import androidx.compose.ui.graphics.Color

val CyanPrimary = Color(0xFF00E5FF)
val CyanPrimaryVariant = Color(0xFF00B4D8)
val TealAccent = Color(0xFF00D2C4)
val PurpleAccent = Color(0xFF7928CA)
val NeonPink = Color(0xFFFF007F)
val NeonGreen = Color(0xFF00E676)
val AmberAlert = Color(0xFFFFB300)
val DangerRed = Color(0xFFFF3366)

val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF111726)
val DarkSurfaceVariant = Color(0xFF192237)
val DarkSurfaceHover = Color(0xFF222D47)
val DarkOutline = Color(0xFF2E3D60)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
