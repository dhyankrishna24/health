package com.example.nfcwriter.model

/**
 * Detailed technical metadata extracted from an NFC tag.
 */
data class TagInfo(
    val uidHex: String,
    val uidDec: String,
    val techList: List<String>,
    val isNdefFormatted: Boolean,
    val ndefType: String,
    val isWritable: Boolean,
    val canMakeReadOnly: Boolean,
    val maxSize: Int,
    val currentSize: Int,
    val records: List<ParsedRecordInfo> = emptyList(),
    val scannedAt: Long = System.currentTimeMillis()
)

data class ParsedRecordInfo(
    val index: Int,
    val tnf: String,
    val type: String,
    val id: String,
    val payloadPreview: String,
    val sizeBytes: Int
)
