package com.example.nfcwriter.nfc

import android.net.Uri
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import com.example.nfcwriter.model.NfcRecordConfig
import com.example.nfcwriter.model.WifiAuthType
import com.example.nfcwriter.model.WriteOptions
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset
import java.nio.charset.StandardCharsets

/**
 * Utility for converting high-level NfcRecordConfig objects into raw Android NdefRecord and NdefMessage.
 */
object PayloadBuilders {

    /**
     * Converts a list of record configs and options into an NdefMessage.
     */
    fun buildNdefMessage(records: List<NfcRecordConfig>, options: WriteOptions): NdefMessage {
        val recordList = mutableListOf<NdefRecord>()

        for (config in records) {
            val record = buildNdefRecord(config)
            recordList.add(record)
        }

        // Append AAR if option is enabled
        if (options.appendAar && options.aarPackageName.isNotBlank()) {
            recordList.add(NdefRecord.createApplicationRecord(options.aarPackageName.trim()))
        }

        if (recordList.isEmpty()) {
            // Default to empty text if nothing provided
            recordList.add(NdefRecord.createTextRecord("en", ""))
        }

        return NdefMessage(recordList.toTypedArray())
    }

    /**
     * Converts a single NfcRecordConfig into an NdefRecord.
     */
    fun buildNdefRecord(config: NfcRecordConfig): NdefRecord {
        return when (config) {
            is NfcRecordConfig.Url -> buildUrlRecord(config.url)
            is NfcRecordConfig.Text -> buildTextRecord(config.text, config.languageCode, config.isUtf8)
            is NfcRecordConfig.VCard -> buildVCardRecord(config)
            is NfcRecordConfig.Wifi -> buildWifiRecord(config)
            is NfcRecordConfig.Bluetooth -> buildBluetoothRecord(config)
            is NfcRecordConfig.AppLauncher -> NdefRecord.createApplicationRecord(config.packageName.trim())
            is NfcRecordConfig.Phone -> buildUriRecord("tel:${config.phoneNumber.trim()}")
            is NfcRecordConfig.Sms -> buildSmsRecord(config.phoneNumber, config.messageBody)
            is NfcRecordConfig.Email -> buildEmailRecord(config.emailAddress, config.subject, config.body)
            is NfcRecordConfig.Geo -> buildGeoRecord(config.latitude, config.longitude, config.label)
            is NfcRecordConfig.CustomMime -> buildCustomMimeRecord(config.mimeType, config.payload)
            is NfcRecordConfig.CustomExternal -> buildExternalRecord(config.domain, config.recordType, config.payload)
            is NfcRecordConfig.RawHex -> buildRawHexRecord(config)
        }
    }

    private fun buildUrlRecord(url: String): NdefRecord {
        val trimmed = url.trim()
        val normalized = if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://") && !trimmed.contains("://")) {
            "https://$trimmed"
        } else {
            trimmed
        }
        return NdefRecord.createUri(normalized)
    }

    private fun buildUriRecord(uriString: String): NdefRecord {
        return NdefRecord.createUri(uriString.trim())
    }

    private fun buildTextRecord(text: String, languageCode: String, isUtf8: Boolean): NdefRecord {
        val lang = languageCode.trim().lowercase().ifEmpty { "en" }
        val langBytes = lang.toByteArray(StandardCharsets.US_ASCII)
        val charset: Charset = if (isUtf8) StandardCharsets.UTF_8 else StandardCharsets.UTF_16
        val textBytes = text.toByteArray(charset)

        // Status byte: Bit 7: 0 = UTF-8, 1 = UTF-16. Bits 5-0: lang code length
        val status = ((if (isUtf8) 0 else 0x80) or (langBytes.size and 0x3F)).toByte()

        val payload = ByteArray(1 + langBytes.size + textBytes.size)
        payload[0] = status
        System.arraycopy(langBytes, 0, payload, 1, langBytes.size)
        System.arraycopy(textBytes, 0, payload, 1 + langBytes.size, textBytes.size)

        return NdefRecord(NdefRecord.TNF_WELL_KNOWN, NdefRecord.RTD_TEXT, ByteArray(0), payload)
    }

    private fun buildVCardRecord(config: NfcRecordConfig.VCard): NdefRecord {
        val vcard = buildString {
            appendLine("BEGIN:VCARD")
            appendLine("VERSION:3.0")
            appendLine("N:${config.lastName};${config.firstName};;;")
            appendLine("FN:${"${config.firstName} ${config.lastName}".trim()}")
            if (config.organization.isNotBlank()) appendLine("ORG:${config.organization}")
            if (config.title.isNotBlank()) appendLine("TITLE:${config.title}")
            if (config.phone.isNotBlank()) appendLine("TEL;TYPE=CELL:${config.phone}")
            if (config.email.isNotBlank()) appendLine("EMAIL;TYPE=INTERNET:${config.email}")
            if (config.website.isNotBlank()) appendLine("URL:${config.website}")
            if (config.address.isNotBlank()) appendLine("ADR;TYPE=WORK:;;${config.address};;;;")
            if (config.note.isNotBlank()) appendLine("NOTE:${config.note}")
            appendLine("END:VCARD")
        }
        return NdefRecord.createMime("text/vcard", vcard.toByteArray(StandardCharsets.UTF_8))
    }

    private fun buildWifiRecord(config: NfcRecordConfig.Wifi): NdefRecord {
        if (!config.useWscBinary) {
            // Wi-Fi URI format (WIFI:S:ssid;T:WPA;P:password;H:false;;)
            val authStr = when (config.authType) {
                WifiAuthType.OPEN -> "nopass"
                WifiAuthType.WEP -> "WEP"
                WifiAuthType.WPA2_PSK, WifiAuthType.WPA3_SAE -> "WPA"
            }
            val uriStr = "WIFI:S:${config.ssid};T:$authStr;P:${config.password};H:${config.isHidden};;"
            return NdefRecord.createUri(uriStr)
        }

        // Standard Wi-Fi Alliance Simple Configuration (WSC) MIME binary payload
        val credStream = ByteArrayOutputStream()

        // 1. Network Index (0x1026) -> 1 byte
        writeTlv(credStream, 0x1026, byteArrayOf(0x01))

        // 2. SSID (0x1045)
        writeTlv(credStream, 0x1045, config.ssid.toByteArray(StandardCharsets.UTF_8))

        // 3. Authentication Type (0x1003) -> 2 bytes big-endian
        val authBuffer = ByteBuffer.allocate(2).order(ByteOrder.BIG_ENDIAN).putShort(config.authType.wscCode).array()
        writeTlv(credStream, 0x1003, authBuffer)

        // 4. Encryption Type (0x100F) -> 2 bytes big-endian
        val encBuffer = ByteBuffer.allocate(2).order(ByteOrder.BIG_ENDIAN).putShort(config.authType.wscEnc).array()
        writeTlv(credStream, 0x100F, encBuffer)

        // 5. Network Key / Password (0x1027)
        if (config.authType != WifiAuthType.OPEN && config.password.isNotBlank()) {
            writeTlv(credStream, 0x1027, config.password.toByteArray(StandardCharsets.UTF_8))
        }

        // 6. MAC Address (0x1020) -> 6 bytes broadcast
        writeTlv(credStream, 0x1020, byteArrayOf(0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte()))

        val credPayload = credStream.toByteArray()

        // Wrap inside Credential Attribute (0x100E)
        val finalStream = ByteArrayOutputStream()
        writeTlv(finalStream, 0x100E, credPayload)

        return NdefRecord.createMime("application/vnd.wfa.wsc", finalStream.toByteArray())
    }

    private fun writeTlv(stream: ByteArrayOutputStream, tag: Int, value: ByteArray) {
        // Tag (2 bytes)
        stream.write((tag ushr 8) and 0xFF)
        stream.write(tag and 0xFF)
        // Length (2 bytes)
        stream.write((value.size ushr 8) and 0xFF)
        stream.write(value.size and 0xFF)
        // Value
        stream.write(value)
    }

    private fun buildBluetoothRecord(config: NfcRecordConfig.Bluetooth): NdefRecord {
        val macClean = config.macAddress.replace(":", "").replace("-", "").uppercase()
        val macBytes = if (macClean.length == 12) {
            val bytes = ByteArray(6)
            for (i in 0 until 6) {
                bytes[i] = macClean.substring(i * 2, i * 2 + 2).toInt(16).toByte()
            }
            // Bluetooth OOB requires address in reverse (little-endian) order
            bytes.reversedArray()
        } else {
            ByteArray(6)
        }

        val eirStream = ByteArrayOutputStream()
        // EIR 0x09 = Complete Local Name
        if (config.deviceName.isNotBlank()) {
            val nameBytes = config.deviceName.toByteArray(StandardCharsets.UTF_8)
            eirStream.write(nameBytes.size + 1) // Length includes type byte
            eirStream.write(0x09)
            eirStream.write(nameBytes)
        }

        val eirData = eirStream.toByteArray()
        val totalLen = 2 + 6 + eirData.size // 2-byte total length header + 6-byte MAC + EIR

        val payload = ByteBuffer.allocate(totalLen).order(ByteOrder.LITTLE_ENDIAN)
        payload.putShort(totalLen.toShort())
        payload.put(macBytes)
        payload.put(eirData)

        return NdefRecord.createMime("application/vnd.bluetooth.ep.oob", payload.array())
    }

    private fun buildSmsRecord(phoneNumber: String, messageBody: String): NdefRecord {
        val encodedBody = Uri.encode(messageBody)
        val uriStr = if (encodedBody.isNotBlank()) {
            "sms:${phoneNumber.trim()}?body=$encodedBody"
        } else {
            "sms:${phoneNumber.trim()}"
        }
        return NdefRecord.createUri(uriStr)
    }

    private fun buildEmailRecord(email: String, subject: String, body: String): NdefRecord {
        val query = mutableListOf<String>()
        if (subject.isNotBlank()) query.add("subject=${Uri.encode(subject)}")
        if (body.isNotBlank()) query.add("body=${Uri.encode(body)}")
        val queryString = if (query.isNotEmpty()) "?${query.joinToString("&")}" else ""
        return NdefRecord.createUri("mailto:${email.trim()}$queryString")
    }

    private fun buildGeoRecord(lat: Double, lng: Double, label: String): NdefRecord {
        val uriStr = if (label.isNotBlank()) {
            "geo:$lat,$lng?q=${Uri.encode(label)}"
        } else {
            "geo:$lat,$lng"
        }
        return NdefRecord.createUri(uriStr)
    }

    private fun buildCustomMimeRecord(mimeType: String, payload: String): NdefRecord {
        val cleanMime = mimeType.trim().ifEmpty { "application/octet-stream" }
        return NdefRecord.createMime(cleanMime, payload.toByteArray(StandardCharsets.UTF_8))
    }

    private fun buildExternalRecord(domain: String, type: String, payload: String): NdefRecord {
        val cleanDomain = domain.trim().ifEmpty { "example.com" }
        val cleanType = type.trim().ifEmpty { "custom" }
        return NdefRecord.createExternal(cleanDomain, cleanType, payload.toByteArray(StandardCharsets.UTF_8))
    }

    private fun buildRawHexRecord(config: NfcRecordConfig.RawHex): NdefRecord {
        val typeBytes = hexStringToByteArray(config.typeHex)
        val idBytes = hexStringToByteArray(config.idHex)
        val payloadBytes = hexStringToByteArray(config.payloadHex)
        return NdefRecord(config.tnf, typeBytes, idBytes, payloadBytes)
    }

    fun hexStringToByteArray(hex: String): ByteArray {
        val clean = hex.replace(" ", "").replace("0x", "").replace(":", "")
        if (clean.isEmpty()) return ByteArray(0)
        val padded = if (clean.length % 2 != 0) "0$clean" else clean
        val result = ByteArray(padded.length / 2)
        for (i in result.indices) {
            val byteStr = padded.substring(i * 2, i * 2 + 2)
            result[i] = byteStr.toIntOrNull(16)?.toByte() ?: 0
        }
        return result
    }

    fun bytesToHex(bytes: ByteArray, separator: String = ":"): String {
        return bytes.joinToString(separator) { "%02X".format(it) }
    }
}
