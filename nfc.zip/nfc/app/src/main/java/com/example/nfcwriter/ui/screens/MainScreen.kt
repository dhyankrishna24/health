package com.example.nfcwriter.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.nfcwriter.ui.components.NfcRadarModal
import com.example.nfcwriter.ui.theme.AmberAlert
import com.example.nfcwriter.ui.theme.CyanPrimary
import com.example.nfcwriter.ui.theme.DangerRed
import com.example.nfcwriter.ui.theme.DarkBackground
import com.example.nfcwriter.ui.theme.DarkOutline
import com.example.nfcwriter.ui.theme.DarkSurface
import com.example.nfcwriter.ui.theme.NeonGreen
import com.example.nfcwriter.ui.theme.TextMuted
import com.example.nfcwriter.ui.theme.TextPrimary
import com.example.nfcwriter.ui.theme.TextSecondary
import com.example.nfcwriter.ui.viewmodel.AppTab
import com.example.nfcwriter.ui.viewmodel.NfcViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: NfcViewModel,
    isNfcAvailable: Boolean,
    isNfcEnabled: Boolean
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val writeDialogState by viewModel.writeDialogState.collectAsState()
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(CyanPrimary.copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Nfc,
                                contentDescription = null,
                                tint = CyanPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "NFC Craft Pro",
                                style = MaterialTheme.typography.titleLarge,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Advanced Tag Writer",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                        }
                    }
                },
                actions = {
                    // NFC Hardware Status Chip
                    val (statusText, statusColor) = when {
                        !isNfcAvailable -> "No NFC" to DangerRed
                        !isNfcEnabled -> "NFC Off" to AmberAlert
                        else -> "NFC Ready" to NeonGreen
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = statusColor.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, statusColor.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .clickable {
                                if (!isNfcEnabled && isNfcAvailable) {
                                    context.startActivity(Intent(Settings.ACTION_NFC_SETTINGS))
                                }
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(statusColor, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = statusText,
                                style = MaterialTheme.typography.labelSmall,
                                color = statusColor,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkBackground
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = currentTab == AppTab.WRITE,
                    onClick = { viewModel.setTab(AppTab.WRITE) },
                    icon = { Icon(Icons.Default.Edit, contentDescription = "Write") },
                    label = { Text("Write") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = CyanPrimary,
                        indicatorColor = CyanPrimary,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
                NavigationBarItem(
                    selected = currentTab == AppTab.MULTI_RECORD,
                    onClick = { viewModel.setTab(AppTab.MULTI_RECORD) },
                    icon = { Icon(Icons.Default.Layers, contentDescription = "Multi-Record") },
                    label = { Text("Multi-Record") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = CyanPrimary,
                        indicatorColor = CyanPrimary,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
                NavigationBarItem(
                    selected = currentTab == AppTab.INSPECT,
                    onClick = { viewModel.setTab(AppTab.INSPECT) },
                    icon = { Icon(Icons.Default.QrCodeScanner, contentDescription = "Inspect") },
                    label = { Text("Inspect") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = CyanPrimary,
                        indicatorColor = CyanPrimary,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
                NavigationBarItem(
                    selected = currentTab == AppTab.PRESETS,
                    onClick = { viewModel.setTab(AppTab.PRESETS) },
                    icon = { Icon(Icons.Default.Bookmarks, contentDescription = "Presets") },
                    label = { Text("Presets") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = CyanPrimary,
                        indicatorColor = CyanPrimary,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
            }
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                AppTab.WRITE -> WriteScreen(viewModel = viewModel)
                AppTab.MULTI_RECORD -> MultiRecordScreen(viewModel = viewModel)
                AppTab.INSPECT -> InspectScreen(viewModel = viewModel)
                AppTab.PRESETS -> PresetsScreen(viewModel = viewModel)
            }

            // Radar Modal Dialog for writing
            NfcRadarModal(
                state = writeDialogState,
                onDismiss = { viewModel.closeWriteDialog() },
                onRetry = {
                    if (currentTab == AppTab.MULTI_RECORD) {
                        viewModel.startMultiRecordWrite()
                    } else {
                        viewModel.startSingleWrite()
                    }
                }
            )
        }
    }
}
