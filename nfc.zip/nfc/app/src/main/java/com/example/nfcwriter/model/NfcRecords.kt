package com.example.nfcwriter.model

import java.util.UUID

/**
 * Supported Wi-Fi Authentication types.
 */
enum class WifiAuthType(val label: String, val wscCode: Short, val wscEnc: Short) {
    OPEN("Open / None", 0x0001, 0x0001),
    WPA2_PSK("WPA2 Personal (PSK)", 0x0020, 0x0008),
    WPA3_SAE("WPA3 Personal (SAE)", 0x0040, 0x0008),
    WEP("WEP (Legacy)", 0x0002, 0x0002)
}

/**
 * Base sealed class for record configurations that can be transformed into NdefRecords.
 */
sealed class NfcRecordConfig(
    val id: String = UUID.randomUUID().toString(),
    val type: NfcRecordType
) {
    abstract fun summary(): String

    data class Url(
        val url: String = "https://"
    ) : NfcRecordConfig(type = NfcRecordType.URL) {
        override fun summary(): String = url
    }

    data class Text(
        val text: String = "",
        val languageCode: String = "en",
        val isUtf8: Boolean = true
    ) : NfcRecordConfig(type = NfcRecordType.TEXT) {
        override fun summary(): String = "[$languageCode/${if (isUtf8) "UTF-8" else "UTF-16"}] $text"
    }

    data class VCard(
        val firstName: String = "",
        val lastName: String = "",
        val organization: String = "",
        val title: String = "",
        val phone: String = "",
        val email: String = "",
        val website: String = "",
        val address: String = "",
        val note: String = ""
    ) : NfcRecordConfig(type = NfcRecordType.VCARD) {
        override fun summary(): String {
            val name = "$firstName $lastName".trim()
            return if (name.isNotEmpty()) "$name (${phone.ifEmpty { email }})" else "vCard Contact"
        }
    }

    data class Wifi(
        val ssid: String = "",
        val password: String = "",
        val authType: WifiAuthType = WifiAuthType.WPA2_PSK,
        val isHidden: Boolean = false,
        val useWscBinary: Boolean = true
    ) : NfcRecordConfig(type = NfcRecordType.WIFI) {
        override fun summary(): String = "SSID: $ssid [${authType.label}]"
    }

    data class Bluetooth(
        val macAddress: String = "",
        val deviceName: String = ""
    ) : NfcRecordConfig(type = NfcRecordType.BLUETOOTH) {
        override fun summary(): String = "$deviceName ($macAddress)"
    }

    data class AppLauncher(
        val packageName: String = ""
    ) : NfcRecordConfig(type = NfcRecordType.APP_LAUNCHER) {
        override fun summary(): String = "App: $packageName"
    }

    data class Phone(
        val phoneNumber: String = ""
    ) : NfcRecordConfig(type = NfcRecordType.PHONE) {
        override fun summary(): String = "Tel: $phoneNumber"
    }

    data class Sms(
        val phoneNumber: String = "",
        val messageBody: String = ""
    ) : NfcRecordConfig(type = NfcRecordType.SMS) {
        override fun summary(): String = "SMS to $phoneNumber: $messageBody"
    }

    data class Email(
        val emailAddress: String = "",
        val subject: String = "",
        val body: String = ""
    ) : NfcRecordConfig(type = NfcRecordType.EMAIL) {
        override fun summary(): String = "Email to $emailAddress: $subject"
    }

    data class Geo(
        val latitude: Double = 0.0,
        val longitude: Double = 0.0,
        val label: String = ""
    ) : NfcRecordConfig(type = NfcRecordType.GEO) {
        override fun summary(): String = "Lat: $latitude, Lng: $longitude ${if (label.isNotEmpty()) "($label)" else ""}"
    }

    data class CustomMime(
        val mimeType: String = "application/json",
        val payload: String = "{\"status\": \"ok\"}"
    ) : NfcRecordConfig(type = NfcRecordType.CUSTOM_MIME) {
        override fun summary(): String = "MIME: $mimeType (${payload.length} chars)"
    }

    data class CustomExternal(
        val domain: String = "example.com",
        val recordType: String = "customType",
        val payload: String = ""
    ) : NfcRecordConfig(type = NfcRecordType.CUSTOM_EXTERNAL) {
        override fun summary(): String = "External: $domain:$recordType"
    }

    data class RawHex(
        val tnf: Short = 1, // TNF_WELL_KNOWN
        val typeHex: String = "55", // 'U' for URI
        val idHex: String = "",
        val payloadHex: String = "04676F6F676C652E636F6D" // https://google.com
    ) : NfcRecordConfig(type = NfcRecordType.RAW_HEX) {
        override fun summary(): String = "TNF $tnf, Payload Hex: $payloadHex"
    }
}
