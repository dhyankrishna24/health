package com.example.nfcwriter.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.nfcwriter.ui.theme.AmberAlert
import com.example.nfcwriter.ui.theme.CyanPrimary
import com.example.nfcwriter.ui.theme.DangerRed
import com.example.nfcwriter.ui.theme.DarkOutline
import com.example.nfcwriter.ui.theme.DarkSurface
import com.example.nfcwriter.ui.theme.DarkSurfaceVariant
import com.example.nfcwriter.ui.theme.TextMuted
import com.example.nfcwriter.ui.theme.TextPrimary
import com.example.nfcwriter.ui.theme.TextSecondary
import com.example.nfcwriter.ui.viewmodel.NfcViewModel

@Composable
fun WriteOptionsSection(
    viewModel: NfcViewModel,
    modifier: Modifier = Modifier
) {
    val options by viewModel.writeOptions.collectAsState()
    var isExpanded by remember { mutableStateOf(false) }
    var showLockConfirmDialog by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = DarkSurfaceVariant.copy(alpha = 0.6f),
        border = BorderStroke(1.dp, if (options.makeReadOnly) AmberAlert else DarkOutline),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = null,
                        tint = CyanPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Card & Write Options",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = if (options.makeReadOnly) "Lock: ON | Format: ${if (options.formatIfUnformatted) "Auto" else "Off"}"
                            else "Format: ${if (options.formatIfUnformatted) "Auto" else "Off"} | Lock: OFF",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (options.makeReadOnly) AmberAlert else TextMuted
                        )
                    }
                }
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = TextSecondary
                )
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 16.dp)) {
                    HorizontalDivider(color = DarkOutline.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(14.dp))

                    // Option 1: Permanent Read-Only Lock
                    OptionRow(
                        title = "Make Card Read-Only (Permanent Lock)",
                        description = "Locks tag hardware. Tag can NEVER be modified or erased again!",
                        checked = options.makeReadOnly,
                        checkedColor = AmberAlert,
                        icon = Icons.Default.Lock,
                        onCheckedChange = { checked ->
                            if (checked) {
                                showLockConfirmDialog = true
                            } else {
                                viewModel.updateWriteOptions { it.copy(makeReadOnly = false) }
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Option 2: Format Unformatted Tags
                    OptionRow(
                        title = "Auto-Format Blank Cards",
                        description = "If tag is unformatted, initialize NDEF partition via NdefFormatable",
                        checked = options.formatIfUnformatted,
                        onCheckedChange = { checked ->
                            viewModel.updateWriteOptions { it.copy(formatIfUnformatted = checked) }
                        }
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Option 3: Append Android Application Record (AAR)
                    OptionRow(
                        title = "Append App Launcher Record (AAR)",
                        description = "Forces scanned Android devices to open/install a specific app",
                        checked = options.appendAar,
                        onCheckedChange = { checked ->
                            viewModel.updateWriteOptions { it.copy(appendAar = checked) }
                        }
                    )

                    if (options.appendAar) {
                        Spacer(modifier = Modifier.height(8.dp))
                        FormTextField(
                            label = "AAR App Package Name",
                            value = options.aarPackageName,
                            onValueChange = { pkg ->
                                viewModel.updateWriteOptions { it.copy(aarPackageName = pkg) }
                            },
                            placeholder = "com.example.myapp"
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Option 4: Force Overwrite
                    OptionRow(
                        title = "Force Overwrite",
                        description = "Silently replace existing tag contents if writable",
                        checked = options.forceOverwrite,
                        onCheckedChange = { checked ->
                            viewModel.updateWriteOptions { it.copy(forceOverwrite = checked) }
                        }
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Option 5: Haptic Feedback
                    OptionRow(
                        title = "Vibration & Haptics",
                        description = "Vibrate on tag detection and write completion",
                        checked = options.vibrateFeedback,
                        onCheckedChange = { checked ->
                            viewModel.updateWriteOptions { it.copy(vibrateFeedback = checked) }
                        }
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Option 6: Sound Feedback
                    OptionRow(
                        title = "Audio Feedback",
                        description = "Play confirmation tone when write completes",
                        checked = options.soundFeedback,
                        onCheckedChange = { checked ->
                            viewModel.updateWriteOptions { it.copy(soundFeedback = checked) }
                        }
                    )
                }
            }
        }
    }

    if (showLockConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showLockConfirmDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = AmberAlert,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "Permanent Tag Lock Warning",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to enable Permanent Read-Only Lock?\n\n" +
                            "Once written, the NFC card's hardware lock bits will be activated. " +
                            "You will NOT be able to overwrite, edit, format, or erase this card ever again.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateWriteOptions { it.copy(makeReadOnly = true) }
                        showLockConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberAlert)
                ) {
                    Text("Enable Permanent Lock", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLockConfirmDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = DarkSurface
        )
    }
}

@Composable
private fun OptionRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    checkedColor: Color = CyanPrimary,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (checked) checkedColor else TextMuted,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
            }
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (checked && icon != null) checkedColor else TextPrimary,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = checkedColor,
                checkedTrackColor = checkedColor.copy(alpha = 0.35f)
            )
        )
    }
}
