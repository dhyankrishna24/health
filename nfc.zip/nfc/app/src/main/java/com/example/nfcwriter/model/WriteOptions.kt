package com.example.nfcwriter.model

/**
 * Options and security settings for NFC write operations.
 */
data class WriteOptions(
    /**
     * If true, makes the NFC tag permanently READ-ONLY after writing.
     * WARNING: This cannot be reversed on most NFC chips (NTAG213, NTAG215, NTAG216, Mifare, etc.).
     */
    val makeReadOnly: Boolean = false,

    /**
     * If true, attempts to format unformatted NFC tags using NdefFormatable.
     */
    val formatIfUnformatted: Boolean = true,

    /**
     * If true, automatically appends an Android Application Record (AAR) to the NDEF message.
     * This instructs Android devices to launch or install the specified app package when tapped.
     */
    val appendAar: Boolean = false,

    /**
     * Package name for the appended AAR record.
     */
    val aarPackageName: String = "",

    /**
     * If true, overwrites any existing NDEF message without confirmation.
     */
    val forceOverwrite: Boolean = true,

    /**
     * Haptic feedback on tag detection and write completion.
     */
    val vibrateFeedback: Boolean = true,

    /**
     * Audio feedback on tag write.
     */
    val soundFeedback: Boolean = true
)
